
The enclosed programs detrend a series called ly within MATLAB.  

The main program is detr_ly.

This program, in turn, calls betav.m

Further instructions are at the top of the detr_ly program.

I appreciate your interest

Sincerely

Julio Rotemberg
jrotemberg@hbs.edu